export class AppConfig {
    public static API_URL = 'http://10.112.32.5/api';
    public static OAUTH_CLIENT_ID = 2;
    public static OAUTH_SECRET = 'nNUdjsVHRZpRAA99pZMr1ctMoOKxu0KW1FTntlkO';
    public static OAUTH_URL = 'http://10.112.32.5/oauth/token';
}
