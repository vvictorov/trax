import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-tracks',
  templateUrl: './my-tracks.component.html',
  styleUrls: ['./my-tracks.component.css']
})
export class MyTracksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
